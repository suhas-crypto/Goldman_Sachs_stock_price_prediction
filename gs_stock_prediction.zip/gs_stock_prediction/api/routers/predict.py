"""
api/routers/predict.py
───────────────────────
FastAPI router for all prediction endpoints.
"""

import logging
from datetime import datetime
from typing import List

import numpy as np
import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, Query

from api.schemas import (
    ForecastPoint,
    ForecastRequest,
    ForecastResponse,
    HealthResponse,
    ModelInfoResponse,
    SinglePredictRequest,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1", tags=["predictions"])


# ── Model registry (injected via app state) ───────────────────────────────────

def get_model_registry(request):
    """FastAPI dependency that retrieves the model registry from app state."""
    return request.app.state.model_registry


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/health", response_model=HealthResponse)
async def health_check(request=None):
    """Returns API health status and loaded model names."""
    from fastapi import Request
    registry = request.app.state.model_registry if request else {}
    return HealthResponse(
        status="healthy",
        models_loaded=list(registry.get("models", {}).keys()),
        last_data_date=str(registry.get("last_data_date", "unknown")),
    )


@router.post("/forecast", response_model=ForecastResponse)
async def forecast(body: ForecastRequest, request=None):
    """
    Multi-step forecast endpoint.

    - Accepts a list of model names and a step count.
    - Returns per-model forecasts + ensemble blend.
    - Confidence intervals included when requested.
    """
    from fastapi import Request

    registry   = request.app.state.model_registry
    models     = registry.get("models", {})
    last_date  = registry.get("last_date_series")
    scaler     = registry.get("scaler")
    last_feats = registry.get("last_features")   # last row of feature matrix

    steps      = body.steps
    used_models = body.models

    if not models:
        raise HTTPException(503, "No models loaded. Run train_pipeline.py first.")

    preds_dict   = {}
    future_dates = pd.bdate_range(
        start=last_date + pd.Timedelta(days=1), periods=steps
    )

    for model_name in used_models:
        if model_name == "ensemble":
            continue
        if model_name not in models:
            logger.warning("Model '%s' not in registry; skipping.", model_name)
            continue
        try:
            model = models[model_name]

            if model_name == "arima":
                preds, _ = model.forecast(steps=steps)
                preds_dict["arima"] = np.array(preds).flatten()

            elif model_name == "prophet":
                fc = model.predict(periods=steps)
                preds_dict["prophet"] = fc["yhat"].values

            elif model_name == "lstm":
                last_seq = registry.get("last_sequence")
                if last_seq is None:
                    continue
                preds_sc = model.forecast_future(last_seq, steps=steps)
                preds_dict["lstm"] = scaler.inverse_transform_col(preds_sc, "Close")

            elif model_name == "xgboost":
                if last_feats is None:
                    continue
                preds_dict["xgboost"] = model.predict_multi_step(last_feats, steps=steps)

        except Exception as exc:
            logger.error("Model '%s' forecast error: %s", model_name, exc)

    # Ensemble
    ensemble_preds = None
    ens_lower = ens_upper = None
    if "ensemble" in used_models and preds_dict:
        ens_model = registry.get("ensemble")
        if ens_model:
            ens_df       = ens_model.predict(preds_dict, compute_ci=True)
            ensemble_preds = ens_df["ensemble"].values
            if "lower" in ens_df.columns:
                ens_lower = ens_df["lower"].values
                ens_upper = ens_df["upper"].values

    # ── Build response ────────────────────────────────────────────────────────
    forecasts_out = {}
    for name, arr in preds_dict.items():
        forecasts_out[name] = [
            ForecastPoint(
                date=str(future_dates[i].date()),
                predicted=round(float(arr[i]), 4),
            )
            for i in range(min(steps, len(arr)))
        ]

    ensemble_out = None
    if ensemble_preds is not None:
        ensemble_out = [
            ForecastPoint(
                date=str(future_dates[i].date()),
                predicted=round(float(ensemble_preds[i]), 4),
                lower_bound=round(float(ens_lower[i]), 4) if ens_lower is not None else None,
                upper_bound=round(float(ens_upper[i]), 4) if ens_upper is not None else None,
            )
            for i in range(min(steps, len(ensemble_preds)))
        ]

    return ForecastResponse(
        ticker="GS",
        generated_at=datetime.utcnow().isoformat() + "Z",
        forecast_days=steps,
        models_used=list(preds_dict.keys()) + (["ensemble"] if ensemble_out else []),
        forecasts=forecasts_out,
        ensemble=ensemble_out,
        metadata={
            "last_known_date": str(last_date.date()) if last_date else None,
            "ci_included":     body.include_confidence_interval,
        },
    )


@router.get("/models", response_model=List[ModelInfoResponse])
async def list_models(request=None):
    """List all loaded models and their metadata."""
    registry = request.app.state.model_registry
    models   = registry.get("models", {})
    infos    = []
    for name, model in models.items():
        info = ModelInfoResponse(model=name)
        if hasattr(model, "best_aic_"):
            info.parameters = {"aic": model.best_aic_,
                                "order": str(getattr(model, "order", None))}
        if hasattr(model, "best_params_"):
            info.parameters = model.best_params_
        infos.append(info)
    return infos


@router.post("/predict/single", response_model=ForecastPoint)
async def predict_single(body: SinglePredictRequest, request=None):
    """
    Quick prediction for next N steps given a single OHLCV context point.
    Uses XGBoost model (fastest inference) if available, else ensemble.
    """
    registry = request.app.state.model_registry
    models   = registry.get("models", {})

    if "xgboost" not in models:
        raise HTTPException(503, "XGBoost model not loaded.")

    last_feats = registry.get("last_features")
    if last_feats is None:
        raise HTTPException(503, "Feature matrix not available.")

    xgb   = models["xgboost"]
    preds = xgb.predict_multi_step(last_feats, steps=body.steps)
    pred  = float(np.mean(preds))

    last_date    = registry.get("last_date_series", pd.Timestamp.now())
    future_dates = pd.bdate_range(start=last_date + pd.Timedelta(days=1),
                                   periods=body.steps)
    return ForecastPoint(
        date=str(future_dates[-1].date()),
        predicted=round(pred, 4),
    )
