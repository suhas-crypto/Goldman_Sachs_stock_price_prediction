# GS Stock Price Prediction — End-to-End ML Pipeline

> **Industry-level time-series forecasting system for Goldman Sachs (NYSE: GS)**
> 26 years of data · 4 models · Weighted ensemble · FastAPI deployment · MLflow tracking

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        DATA LAYER                                       │
│  Barchart · Investing.com · MarketWatch · NASDAQ · Yahoo Finance        │
│  (1999–2026, ~6,800 trading days)                                       │
└────────────────────────────┬────────────────────────────────────────────┘
                             │  src/data/loader.py
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    PREPROCESSING & FEATURE ENGINEERING                  │
│  Cleaning · Outlier removal · 80+ technical indicators                  │
│  Lag features · Rolling stats · Calendar encoding                       │
└────────────────────────────┬────────────────────────────────────────────┘
                             │  src/features/engineer.py
              ┌──────────────┼──────────────────────────┐
              ▼              ▼              ▼            ▼
       ┌────────────┐ ┌────────────┐ ┌──────────┐ ┌──────────────┐
       │   ARIMA/   │ │  Prophet   │ │   BiLSTM │ │   XGBoost /  │
       │   SARIMA   │ │ (Meta/FB)  │ │ +Attention│ │   LightGBM   │
       │            │ │ +Holidays  │ │ +Dropout  │ │ +Optuna HPO  │
       └─────┬──────┘ └─────┬──────┘ └────┬─────┘ └──────┬───────┘
             └──────────────┴──────────────┴──────────────┘
                                    │
                             ┌──────▼──────┐
                             │   ENSEMBLE   │
                             │ (Optimised   │
                             │  weights via │
                             │  scipy SLSQP)│
                             └──────┬───────┘
                                    │
              ┌─────────────────────┼──────────────────────┐
              ▼                     ▼                      ▼
       ┌─────────────┐      ┌──────────────┐      ┌───────────────┐
       │   MLflow    │      │  FastAPI     │      │    Docker /   │
       │  Tracking   │      │  REST API    │      │  Compose      │
       │  (metrics / │      │  /forecast   │      │  deployment   │
       │   artefacts)│      │  /health     │      │               │
       └─────────────┘      └──────────────┘      └───────────────┘
```

---

## Project Structure

```
gs_stock_prediction/
├── config.py                   # All hyperparameters & paths
├── requirements.txt
├── .env.example
│
├── data/
│   ├── raw/                    # Source CSVs (5 providers)
│   └── processed/              # Cleaned data, forecasts
│
├── src/
│   ├── data/
│   │   ├── loader.py           # Multi-source merge & dedup
│   │   └── preprocessor.py     # Cleaning, split, scalers, sequences
│   ├── features/
│   │   └── engineer.py         # 80+ technical indicators
│   ├── models/
│   │   ├── arima_model.py      # ARIMA/SARIMA with auto order selection
│   │   ├── prophet_model.py    # Meta Prophet + US holidays
│   │   ├── lstm_model.py       # BiLSTM + Self-Attention
│   │   ├── xgboost_model.py    # XGBoost/LightGBM + Optuna HPO + SHAP
│   │   └── ensemble.py         # Optimised weighted blend
│   └── evaluation/
│       └── metrics.py          # MAE, RMSE, MAPE, DA, Sharpe, IC
│
├── pipelines/
│   ├── train_pipeline.py       # Full train → evaluate → log → save
│   └── predict_pipeline.py     # Load artefacts → forward forecast
│
├── api/
│   ├── main.py                 # FastAPI app with lifespan loading
│   ├── schemas.py              # Pydantic v2 request/response schemas
│   └── routers/predict.py      # /forecast, /health, /models endpoints
│
├── deployment/
│   ├── Dockerfile              # Multi-stage, non-root, healthcheck
│   └── docker-compose.yml      # API + MLflow + optional Prometheus/Grafana
│
├── notebooks/
│   └── 01_EDA_Analysis.py      # Full EDA (10 sections, 8 plots)
│
├── tests/
│   ├── test_data.py            # Data loading & preprocessing
│   ├── test_models.py          # Model train/predict/serialise
│   └── test_api.py             # FastAPI endpoint tests
│
└── models_saved/               # Serialised model artefacts
```

---

## Quickstart

### 1. Install dependencies

```bash
cd gs_stock_prediction
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Run EDA

```bash
python notebooks/01_EDA_Analysis.py
# → 8 plots saved to notebooks/plots/
```

### 3. Train all models

```bash
python pipelines/train_pipeline.py --model all
# Trains ARIMA, Prophet, LSTM, XGBoost; optimises ensemble; logs to MLflow
```

Train individual models:
```bash
python pipelines/train_pipeline.py --model arima
python pipelines/train_pipeline.py --model lstm
```

### 4. Generate a forecast

```bash
python pipelines/predict_pipeline.py --steps 30 --output my_forecast.csv
```

### 5. Start the REST API

```bash
uvicorn api.main:app --host 0.0.0.0 --port 8000 --reload
# Docs: http://localhost:8000/docs
```

### 6. Deploy with Docker

```bash
cd deployment
docker compose up --build
# API       → http://localhost:8000
# MLflow UI → http://localhost:5000
```

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET`  | `/api/v1/health` | Health check + loaded models |
| `POST` | `/api/v1/forecast` | Multi-step, multi-model forecast |
| `POST` | `/api/v1/predict/single` | Quick single-step prediction |
| `GET`  | `/api/v1/models` | List loaded models + metadata |

### Example forecast request

```bash
curl -X POST http://localhost:8000/api/v1/forecast \
  -H "Content-Type: application/json" \
  -d '{
    "steps": 30,
    "models": ["arima", "lstm", "xgboost", "ensemble"],
    "include_confidence_interval": true
  }'
```

---

## Models

| Model | Approach | Key Features |
|-------|----------|-------------|
| **ARIMA/SARIMA** | Classical statistical | Auto order via AIC / pmdarima; weekly seasonality |
| **Prophet** | Decomposable trend | US market holidays; changepoint detection |
| **BiLSTM + Attention** | Deep learning | 60-day lookback; Huber loss; EarlyStopping |
| **XGBoost / LightGBM** | Gradient boosting | Optuna HPO (50 trials); SHAP feature importance |
| **Ensemble** | Weighted blend | SLSQP-optimised weights on validation RMSE |

---

## Feature Engineering (80+ features)

**Trend:** SMA (5/10/20/50/200), EMA, Price/SMA ratios  
**Momentum:** RSI-14, MACD, Stochastic %K/%D, Williams %R, ROC (5/10/21)  
**Volatility:** Bollinger Bands (upper/mid/lower/width/%B), ATR, Historical Volatility (21/63 day)  
**Volume:** OBV, VWAP, Volume SMA ratio  
**Price patterns:** High-Low range, shadow lengths, Close-Open diff  
**Lag features:** Close lagged by 1, 2, 3, 5, 10, 21 days  
**Rolling stats:** Mean, Std, Min, Max over 5/10/20/50/200 days  
**Calendar:** Day-of-week, Month, Quarter, Month-end, sin/cos cyclical encoding  

---

## Evaluation Metrics

| Metric | Description |
|--------|-------------|
| **MAE** | Mean Absolute Error |
| **RMSE** | Root Mean Squared Error |
| **MAPE** | Mean Absolute Percentage Error |
| **SMAPE** | Symmetric MAPE |
| **R²** | Coefficient of Determination |
| **Directional Accuracy** | % of correct up/down predictions |
| **Sharpe Ratio** | Risk-adjusted strategy return (annualised) |
| **Max Drawdown** | Maximum peak-to-trough loss |
| **IC** | Spearman rank information coefficient |

---

## Run Tests

```bash
# All tests
pytest tests/ -v

# Individual suites
pytest tests/test_data.py -v
pytest tests/test_models.py -v
pytest tests/test_api.py -v

# With coverage
pytest tests/ --cov=src --cov=api --cov-report=term-missing
```

---

## MLflow Experiment Tracking

MLflow logs all training runs automatically. View the UI at:
```bash
mlflow ui --backend-store-uri mlruns --port 5000
# → http://localhost:5000
```

Tracked per run: hyperparameters, MAE/RMSE/MAPE/Directional-Accuracy per model,
ensemble weights, forecast CSV artefact.

---

## Configuration

All tunable parameters live in `config.py`:
- Data paths, target column, forecast horizon
- Train/val/test split ratios
- ARIMA max order, SARIMA seasonality
- Prophet changepoint / seasonality priors
- LSTM lookback, units, dropout, learning rate
- Optuna trial count, CV folds
- Ensemble default weights
- API host/port

---

## Data Sources

| Source | Coverage | Notes |
|--------|----------|-------|
| Barchart (via proxy) | 1999–present | OHLCV |
| Investing.com (via proxy) | 1999–present | OHLCV |
| MarketWatch | 1999–present | OHLCV |
| NASDAQ | Recent (2024–2026) | $-formatted close |
| Yahoo Finance | 1999–present | Primary/highest priority |

Duplicate dates resolved by source priority: Yahoo > Investing.com > Barchart > MarketWatch > NASDAQ.

---

## License

For educational and research purposes. Past stock performance does not guarantee future results.
This system is not financial advice.
