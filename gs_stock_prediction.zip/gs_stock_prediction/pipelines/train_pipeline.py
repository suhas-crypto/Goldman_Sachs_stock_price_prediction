"""
pipelines/train_pipeline.py
─────────────────────────────
Orchestrates the full training pipeline:

  1.  Load & merge all GS data sources
  2.  Clean + feature-engineer
  3.  Temporal split (train / val / test)
  4.  Train ARIMA, Prophet, LSTM, XGBoost, LightGBM
  5.  Optimise ensemble weights on validation set
  6.  Evaluate all models on held-out test set
  7.  Log everything to MLflow
  8.  Save all model artefacts

Run:
    cd gs_stock_prediction
    python pipelines/train_pipeline.py [--model all|arima|prophet|lstm|xgboost]
"""

import argparse
import logging
import sys
import warnings
from pathlib import Path

import mlflow
import numpy as np
import pandas as pd

# ── path fix: run from project root ───────────────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import config as cfg
from src.data.loader import load_all_sources
from src.data.preprocessor import clean, temporal_split, DataScaler, prepare_data
from src.evaluation.metrics import regression_metrics, compare_models
from src.features.engineer import build_feature_set, get_feature_columns
from src.models.arima_model import ARIMAForecaster
from src.models.ensemble import EnsembleForecaster, build_ensemble_forecast_df
from src.models.lstm_model import LSTMForecaster
from src.models.prophet_model import ProphetForecaster
from src.models.xgboost_model import GBForecaster

warnings.filterwarnings("ignore")

# ── Logging setup ─────────────────────────────────────────────────────────────
import io as _io

# Force UTF-8 on stdout so Unicode chars don't crash on Windows cp1252 terminals
_stdout_handler = logging.StreamHandler(
    _io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    if hasattr(sys.stdout, "buffer") else sys.stdout
)
_stdout_handler.setFormatter(logging.Formatter(cfg.LOG_FORMAT))

logging.basicConfig(
    level=getattr(logging, cfg.LOG_LEVEL),
    format=cfg.LOG_FORMAT,
    handlers=[
        _stdout_handler,
        logging.FileHandler(cfg.LOGS_DIR / "train.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger("train_pipeline")


# ── Step 1: Data ──────────────────────────────────────────────────────────────

def step_load_data() -> pd.DataFrame:
    logger.info("=== STEP 1: Load & Merge Data Sources ===")
    df_raw = load_all_sources()
    df_clean = clean(df_raw)
    df_feat  = build_feature_set(df_clean)
    logger.info("Feature matrix: %d rows × %d columns", *df_feat.shape)
    return df_feat


# ── Step 2: ARIMA ─────────────────────────────────────────────────────────────

def step_train_arima(train_df: pd.DataFrame, test_df: pd.DataFrame,
                     run) -> np.ndarray:
    logger.info("=== STEP 2: ARIMA / SARIMA ===")
    series = train_df[cfg.TARGET_COL]

    arima = ARIMAForecaster(use_auto=True)
    arima.auto_fit(series)

    # Forecast on test horizon
    preds, ci = arima.forecast(steps=len(test_df))
    preds_arr = np.array(preds).flatten()[: len(test_df)]

    metrics = regression_metrics(
        test_df[cfg.TARGET_COL].values, preds_arr, label="ARIMA"
    )

    mlflow.log_params({"arima_order": str(arima.order),
                       "arima_seasonal": str(arima.seasonal_order)})
    mlflow.log_metrics({f"arima_{k}": v for k, v in metrics.items()})
    arima.save()
    return preds_arr


# ── Step 3: Prophet ───────────────────────────────────────────────────────────

def step_train_prophet(train_df: pd.DataFrame, test_df: pd.DataFrame,
                       run) -> np.ndarray:
    logger.info("=== STEP 3: Prophet ===")
    pf = ProphetForecaster()
    pf.fit(train_df)

    forecast = pf.predict(periods=len(test_df))
    preds_arr = forecast["yhat"].values[: len(test_df)]

    metrics = regression_metrics(
        test_df[cfg.TARGET_COL].values, preds_arr, label="Prophet"
    )
    mlflow.log_metrics({f"prophet_{k}": v for k, v in metrics.items()})
    pf.save()
    return preds_arr


# ── Step 4: LSTM ──────────────────────────────────────────────────────────────

def step_train_lstm(
    train_df: pd.DataFrame,
    val_df:   pd.DataFrame,
    test_df:  pd.DataFrame,
    feature_cols: list,
    scaler: DataScaler,
    run,
) -> np.ndarray:
    logger.info("=== STEP 4: Bidirectional LSTM ===")

    # ── Check backend availability BEFORE importing heavy DL deps ─────────────
    from src.models.lstm_model import BACKEND as LSTM_BACKEND
    if LSTM_BACKEND == "none":
        logger.warning(
            "No deep-learning backend found (PyTorch or TensorFlow required). "
            "LSTM step will be skipped.\n"
            "  Install PyTorch (recommended):\n"
            "    pip install torch --index-url https://download.pytorch.org/whl/cpu\n"
            "  Then re-run the pipeline."
        )
        return np.full(len(test_df), np.nan)

    logger.info("LSTM backend: %s", LSTM_BACKEND)
    from src.data.preprocessor import build_sequences

    lookback = cfg.LSTM_LOOKBACK

    def _scale_and_seq(df):
        sc = scaler.transform(df, feature_cols)
        ordered = [cfg.TARGET_COL] + [c for c in feature_cols if c != cfg.TARGET_COL]
        arr = sc[[c for c in ordered if c in sc.columns]].values.astype("float32")
        return build_sequences(arr, lookback=lookback)

    X_tr, y_tr = _scale_and_seq(train_df)
    X_va, y_va = _scale_and_seq(val_df)
    X_te, y_te = _scale_and_seq(test_df)

    if len(X_tr) == 0:
        logger.warning("Not enough data for LSTM; skipping.")
        return np.full(len(test_df), np.nan)

    n_features = X_tr.shape[2]
    lf = LSTMForecaster(n_features=n_features)
    lf.build()
    history = lf.fit(X_tr, y_tr, X_va, y_va)

    preds_sc = lf.predict(X_te).flatten()
    preds    = scaler.inverse_transform_col(preds_sc, cfg.TARGET_COL)

    # Align with test_df
    n_preds = min(len(preds), len(test_df))
    preds_arr = np.full(len(test_df), np.nan)
    preds_arr[-n_preds:] = preds[-n_preds:]

    actuals = test_df[cfg.TARGET_COL].values
    metrics = regression_metrics(
        actuals[~np.isnan(preds_arr)],
        preds_arr[~np.isnan(preds_arr)],
        label="LSTM"
    )

    mlflow.log_params({"lstm_lookback": lookback,
                       "lstm_units": cfg.LSTM_UNITS,
                       "lstm_epochs_run": len(history["loss"])})
    mlflow.log_metrics({f"lstm_{k}": v for k, v in metrics.items()})
    lf.save()
    return preds_arr


# ── Step 5: XGBoost + LightGBM ───────────────────────────────────────────────

def step_train_xgboost(
    train_df:     pd.DataFrame,
    val_df:       pd.DataFrame,
    test_df:      pd.DataFrame,
    feature_cols: list,
    run,
    model_type: str = "xgboost",
) -> np.ndarray:
    logger.info("=== STEP 5: %s ===", model_type.upper())
    X_cols = [c for c in feature_cols if c != cfg.TARGET_COL]

    X_tr = train_df[X_cols].values
    y_tr = train_df[cfg.TARGET_COL].values
    X_va = val_df[X_cols].values
    y_va = val_df[cfg.TARGET_COL].values
    X_te = test_df[X_cols].values

    gb = GBForecaster(model_type=model_type, n_trials=cfg.XGB_N_TRIALS)
    gb.optimise(X_tr, y_tr, feature_names=X_cols)
    gb.fit(X_tr, y_tr, X_va, y_va, feature_names=X_cols)

    preds_arr = gb.predict(X_te)

    metrics = regression_metrics(
        test_df[cfg.TARGET_COL].values, preds_arr, label=model_type.upper()
    )
    mlflow.log_params({f"{model_type}_best_params": str(gb.best_params_)})
    mlflow.log_metrics({f"{model_type}_{k}": v for k, v in metrics.items()})
    gb.save()
    return preds_arr


# ── Step 6: Ensemble ──────────────────────────────────────────────────────────

def step_ensemble(
    val_preds:  dict,
    test_preds: dict,
    val_df:     pd.DataFrame,
    test_df:    pd.DataFrame,
    run,
) -> pd.DataFrame:
    logger.info("=== STEP 6: Ensemble ===")
    ens = EnsembleForecaster()

    # Align val predictions to same length
    val_actuals = val_df[cfg.TARGET_COL].values
    min_len = min(len(val_actuals), min(len(v) for v in val_preds.values()))
    aligned_val  = {k: v[-min_len:] for k, v in val_preds.items()}
    ens.fit_weights(aligned_val, val_actuals[-min_len:])

    # Test ensemble
    forecast_df = build_ensemble_forecast_df(
        dates=test_df.index,
        preds_dict=test_preds,
        actuals=test_df[cfg.TARGET_COL].values,
        weights=ens.weights,
    )

    metrics = regression_metrics(
        forecast_df["actual"].dropna().values,
        forecast_df["ensemble"].iloc[:len(forecast_df["actual"].dropna())].values,
        label="Ensemble"
    )
    mlflow.log_metrics({f"ensemble_{k}": v for k, v in metrics.items()})
    ens.save()

    # Save forecast CSV
    out_path = cfg.DATA_PROC_DIR / "test_forecast.csv"
    forecast_df.to_csv(out_path)
    logger.info("Test forecast saved -> %s", out_path)
    mlflow.log_artifact(str(out_path))

    return forecast_df


# ── Main ──────────────────────────────────────────────────────────────────────

def main(models_to_train: str = "all"):
    # Ensure tracking URI is always a valid file:// URI on Windows
    tracking_uri = cfg.MLFLOW_TRACKING_URI
    if not tracking_uri.startswith(("file://", "http://", "https://", "sqlite://",
                                     "postgresql://", "mysql://", "mssql://")):
        from urllib.request import pathname2url
        tracking_uri = "file:///" + pathname2url(str(tracking_uri)).lstrip("/")
    mlflow.set_tracking_uri(tracking_uri)
    mlflow.set_experiment(cfg.MLFLOW_EXPERIMENT)

    with mlflow.start_run(run_name=f"full_pipeline_{models_to_train}") as run:
        mlflow.log_params({
            "ticker":         cfg.TICKER,
            "target_col":     cfg.TARGET_COL,
            "forecast_days":  cfg.FORECAST_DAYS,
            "train_ratio":    cfg.TRAIN_RATIO,
            "models":         models_to_train,
        })

        # ── Load data ─────────────────────────────────────────────────────────
        df = step_load_data()

        # ── Temporal split ────────────────────────────────────────────────────
        train_df, val_df, test_df = temporal_split(df)

        # ── Scaler (fit on train) ─────────────────────────────────────────────
        feature_cols = get_feature_columns(df)
        scaler = DataScaler("minmax")
        train_sc = scaler.fit_transform(train_df, feature_cols)
        scaler.save(cfg.MODELS_DIR / "feature_scaler.pkl")

        val_preds  = {}
        test_preds = {}
        train_flag = lambda m: models_to_train in ("all", m)

        # ── ARIMA ─────────────────────────────────────────────────────────────
        if train_flag("arima"):
            p = step_train_arima(train_df, test_df, run)
            val_preds["arima"]  = step_train_arima(train_df, val_df, run)
            test_preds["arima"] = p

        # ── Prophet ───────────────────────────────────────────────────────────
        if train_flag("prophet"):
            p = step_train_prophet(train_df, test_df, run)
            val_preds["prophet"]  = step_train_prophet(train_df, val_df, run)
            test_preds["prophet"] = p

        # ── LSTM ──────────────────────────────────────────────────────────────
        if train_flag("lstm"):
            p = step_train_lstm(train_df, val_df, test_df, feature_cols, scaler, run)
            val_preds["lstm"]  = step_train_lstm(train_df, val_df, val_df,
                                                   feature_cols, scaler, run)
            test_preds["lstm"] = p

        # ── XGBoost ───────────────────────────────────────────────────────────
        if train_flag("xgboost"):
            p = step_train_xgboost(train_df, val_df, test_df, feature_cols, run,
                                   model_type="xgboost")
            val_preds["xgboost"]  = step_train_xgboost(train_df, val_df, val_df,
                                                        feature_cols, run, "xgboost")
            test_preds["xgboost"] = p

        # ── Ensemble ──────────────────────────────────────────────────────────
        if len(test_preds) > 1:
            forecast_df = step_ensemble(val_preds, test_preds, val_df, test_df, run)
            logger.info("\nFinal Ensemble Forecast (first 5 rows):\n%s",
                        forecast_df.head().to_string())

        # ── Model comparison table ─────────────────────────────────────────────
        actuals = test_df[cfg.TARGET_COL].values
        valid_preds = {k: v for k, v in test_preds.items()
                       if not np.all(np.isnan(v))}
        if valid_preds:
            comparison = compare_models(actuals, valid_preds)
            logger.info("\nModel Comparison on Test Set:\n%s", comparison.to_string())
            comparison.to_csv(cfg.DATA_PROC_DIR / "model_comparison.csv")
            mlflow.log_artifact(str(cfg.DATA_PROC_DIR / "model_comparison.csv"))

        logger.info("Training pipeline complete. Run ID: %s", run.info.run_id)

    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="GS Stock Prediction — Train Pipeline")
    parser.add_argument(
        "--model",
        choices=["all", "arima", "prophet", "lstm", "xgboost"],
        default="all",
        help="Which model(s) to train (default: all)",
    )
    args = parser.parse_args()
    sys.exit(main(args.model))
