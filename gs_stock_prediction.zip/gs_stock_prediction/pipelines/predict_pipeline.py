"""
pipelines/predict_pipeline.py
──────────────────────────────
Loads saved model artefacts and produces a forward forecast
for the next FORECAST_DAYS business days.

Run:
    cd gs_stock_prediction
    python pipelines/predict_pipeline.py [--steps 30] [--output forecast.csv]
"""

import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import config as cfg
from src.data.loader import load_all_sources
from src.data.preprocessor import clean, DataScaler
from src.evaluation.metrics import regression_metrics
from src.features.engineer import build_feature_set, get_feature_columns
from src.models.arima_model import ARIMAForecaster
from src.models.ensemble import EnsembleForecaster
from src.models.lstm_model import LSTMForecaster
from src.models.prophet_model import ProphetForecaster
from src.models.xgboost_model import GBForecaster

logging.basicConfig(
    level=getattr(logging, cfg.LOG_LEVEL),
    format=cfg.LOG_FORMAT,
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("predict_pipeline")


def load_models() -> dict:
    """Load all available saved models. Missing models are skipped gracefully."""
    models = {}

    arima_path = cfg.MODELS_DIR / "arima_model.pkl"
    if arima_path.exists():
        try:
            models["arima"] = ARIMAForecaster.load(arima_path)
            logger.info("ARIMA model loaded.")
        except Exception as e:
            logger.warning("Could not load ARIMA: %s", e)

    prophet_path = cfg.MODELS_DIR / "prophet_model.json"
    if not prophet_path.exists():
        prophet_path = cfg.MODELS_DIR / "prophet_model.pkl"
    if prophet_path.exists():
        try:
            models["prophet"] = ProphetForecaster.load(prophet_path)
            logger.info("Prophet model loaded.")
        except Exception as e:
            logger.warning("Could not load Prophet: %s", e)

    lstm_path = cfg.MODELS_DIR / "lstm_model.h5"
    if lstm_path.exists():
        try:
            models["lstm"] = LSTMForecaster.load(lstm_path)
            logger.info("LSTM model loaded.")
        except Exception as e:
            logger.warning("Could not load LSTM: %s", e)

    xgb_path = cfg.MODELS_DIR / "xgboost_model.pkl"
    if xgb_path.exists():
        try:
            models["xgboost"] = GBForecaster.load(xgb_path, model_type="xgboost")
            logger.info("XGBoost model loaded.")
        except Exception as e:
            logger.warning("Could not load XGBoost: %s", e)

    if not models:
        raise RuntimeError(
            "No trained models found in models_saved/. "
            "Run train_pipeline.py first."
        )

    return models


def run_forecast(steps: int = cfg.FORECAST_DAYS) -> pd.DataFrame:
    """
    Full predict pipeline:
      1. Load latest data
      2. Feature-engineer
      3. Run each model forward
      4. Blend with saved ensemble weights
      5. Return dated forecast DataFrame
    """
    logger.info("Loading latest GS data …")
    df_raw  = load_all_sources()
    df_c    = clean(df_raw)
    df_feat = build_feature_set(df_c)

    feature_cols = get_feature_columns(df_feat)

    # Load scaler
    scaler = DataScaler()
    scaler_path = cfg.MODELS_DIR / "feature_scaler.pkl"
    if scaler_path.exists():
        scaler.load(scaler_path)
    else:
        logger.warning("Scaler not found; fitting on full dataset.")
        scaler.fit_transform(df_feat, feature_cols)

    # Future dates
    last_date    = df_feat.index.max()
    future_dates = pd.bdate_range(start=last_date + pd.Timedelta(days=1),
                                   periods=steps)

    models   = load_models()
    preds_d  = {}

    # ── ARIMA ─────────────────────────────────────────────────────────────────
    if "arima" in models:
        try:
            preds, ci = models["arima"].forecast(steps=steps)
            preds_d["arima"] = np.array(preds).flatten()
        except Exception as e:
            logger.warning("ARIMA forecast failed: %s", e)

    # ── Prophet ───────────────────────────────────────────────────────────────
    if "prophet" in models:
        try:
            fc = models["prophet"].predict(periods=steps)
            preds_d["prophet"] = fc["yhat"].values
        except Exception as e:
            logger.warning("Prophet forecast failed: %s", e)

    # ── LSTM ──────────────────────────────────────────────────────────────────
    if "lstm" in models:
        try:
            lf       = models["lstm"]
            lookback = lf.lookback
            df_sc    = scaler.transform(df_feat, feature_cols)
            ordered  = [cfg.TARGET_COL] + [c for c in feature_cols
                                            if c != cfg.TARGET_COL and c in df_sc.columns]
            arr      = df_sc[ordered].values.astype("float32")
            last_seq = arr[-lookback:]
            preds_sc = lf.forecast_future(last_seq, steps=steps)
            preds_d["lstm"] = scaler.inverse_transform_col(preds_sc, cfg.TARGET_COL)
        except Exception as e:
            logger.warning("LSTM forecast failed: %s", e)

    # ── XGBoost ───────────────────────────────────────────────────────────────
    if "xgboost" in models:
        try:
            gb     = models["xgboost"]
            X_cols = [c for c in feature_cols if c != cfg.TARGET_COL
                      and c in df_feat.columns]
            X_last = df_feat[X_cols].iloc[[-1]].values
            preds_d["xgboost"] = gb.predict_multi_step(X_last, steps=steps)
        except Exception as e:
            logger.warning("XGBoost forecast failed: %s", e)

    if not preds_d:
        raise RuntimeError("All model forecasts failed.")

    # ── Ensemble blend ────────────────────────────────────────────────────────
    ens_path = cfg.MODELS_DIR / "ensemble_weights.pkl"
    if ens_path.exists():
        ens = EnsembleForecaster.load(ens_path)
    else:
        ens = EnsembleForecaster()

    ens_df = ens.predict(preds_d)

    # Build output DataFrame
    out = pd.DataFrame(preds_d, index=future_dates[:len(ens_df)])
    out["ensemble"] = ens_df["ensemble"].values
    if "lower" in ens_df.columns:
        out["ci_lower"] = ens_df["lower"].values
        out["ci_upper"] = ens_df["upper"].values

    logger.info("\nForecast for next %d business days:\n%s", steps, out.to_string())
    return out


def main():
    parser = argparse.ArgumentParser(
        description="GS Stock Prediction — Forward Forecast"
    )
    parser.add_argument("--steps",  type=int,  default=cfg.FORECAST_DAYS,
                        help="Number of business days to forecast")
    parser.add_argument("--output", type=str,  default="forecast_output.csv",
                        help="Output CSV filename (saved in data/processed/)")
    args = parser.parse_args()

    forecast = run_forecast(steps=args.steps)

    out_path = cfg.DATA_PROC_DIR / args.output
    forecast.to_csv(out_path)
    logger.info("Forecast saved -> %s", out_path)


if __name__ == "__main__":
    main()
